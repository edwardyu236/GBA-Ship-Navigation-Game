=====================
Ship Navigation Game
v1.0 GBA
by Edward Sum Lok Yu
=====================
Game:
Navigate your ship in the sea and avoid hitting obstacles.
Colliding with obstacles ends the game.
The player wins if the game ends with a score above 1000.

There are Shield Powerups that enables some protection against obstacles.
After a collision, the protection is disabled.
(Note: the protection is not immediately disabled to give the user a chance after colliding with an obstacle.)
=====================
Controls:
Start (Enter) - Go between states as needed
D-Pad (Arrow Keys) - Control the ship
